#!/usr/bin/env python3
"""
简单JSONL读取示例
"""

import json
import os
import re
from funasr import AutoModel
from funasr.utils.postprocess_utils import rich_transcription_postprocess
import torch
import unicodedata
import string
import editdistance
from typing import List, Union, Dict, Any

# 简单读取JSONL文件的前几行
def simple_read_jsonl(file_path, limit=1):
    """简单读取JSONL文件的前几行"""
    results = []
    count = 0

    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if count >= limit:
                break
            line = line.strip()
            if line:
                data = json.loads(line)
                results.append(data)
                count += 1

    return results

# 读取JSONL文件的所有行
def read_jsonl(file_path):
    """读取JSONL文件的所有行"""
    results = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                data = json.loads(line)
                results.append(data)
    return results

# 计算目标发音人识别字错率
def char_diff_ratio(str1, str2):
    """
    计算两个字符串中不相同字的百分比

    返回: (不同字数, 总字数, 不同百分比)
    """
    # 按字拆分（中文每个字一个元素）
    chars1 = list(str1)
    chars2 = list(str2)

    # 对齐长度：短的补空字符，或者只比较到最短长度
    # 这里采用：以较长的为准，短缺的也算不同
    max_len = max(len(chars1), len(chars2))

    diff_count = 0
    total = max_len

    for i in range(max_len):
        c1 = chars1[i] if i < len(chars1) else ''
        c2 = chars2[i] if i < len(chars2) else ''
        if c1 != c2:
            diff_count += 1

    percentage = (diff_count / total) * 100 if total > 0 else 0

    return diff_count, total, percentage

# 去掉字符串中的标点符号
'''
def remove_punctuation(text):
    """去掉字符串中的标点符号，只保留文字（中文、英文、数字）"""
    # 保留：中文字符 \u4e00-\u9fa5、英文 a-zA-Z、数字 0-9
    # 去掉所有其他字符（标点、特殊符号等）
    return re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9\s]', '', text)
'''
def remove_punctuation(text):
    """去掉字符串中的标点符号，只保留文字（中文、英文、数字），同时去掉开头的空格"""
    # 保留：中文字符 \u4e00-\u9fa5、英文 a-zA-Z、数字 0-9
    # 去掉所有其他字符（标点、特殊符号等）
    text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9\s]', '', text)
    # 去掉开头的空格（包括制表符、换行符等），保留中间和结尾的空格
    text = re.sub(r'^\s+', '', text)
    return text

def normalize_text(text: str) -> str:
    """
    ASR 文本归一化：
    1. Unicode 规范化 (NFKC) —— 全半角转换
    2. 转小写
    3. 去掉前后空白
    4. 移除所有标点（Unicode 类别 P*）和空白字符（包括内部空格）
    """
    if text is None:
        return ""
    text = str(text)

    # 1. NFKC 规范化（全角字母数字转半角等）
    text = unicodedata.normalize("NFKC", text)

    # 2. 转小写
    text = text.lower()

    # 3. 去掉前后空白
    text = text.strip()

    # 4. 过滤：去掉所有标点和空白（只保留字母、数字、汉字等非标点非空白字符）
    normalized_chars = []
    for ch in text:
        # 如果是空白或标点（Unicode 类别以 P 开头），跳过
        if ch in string.whitespace or unicodedata.category(ch).startswith("P"):
            continue
        normalized_chars.append(ch)

    return "".join(normalized_chars)


class CERMetric:
    """
    Character Error Rate (CER) 度量类（ASR 专用）
    """

    def __init__(self):
        self.reset()

    def reset(self):
        """清空统计"""
        self.total_chars = 0
        self.total_errors = 0
        self.per_sample_results = []

    def update(self, preds: Union[str, List[str]], targets: Union[str, List[str]]):
        """更新度量"""
        if isinstance(preds, str):
            preds = [preds]
        if isinstance(targets, str):
            targets = [targets]
        assert len(preds) == len(targets), "preds 和 targets 长度必须一致"

        for pred, target in zip(preds, targets):
            orig_pred = pred
            orig_target = target

            norm_pred = normalize_text(pred)
            norm_target = normalize_text(target)

            # 计算编辑距离（直接传字符串，无需转 list）
            errors = editdistance.eval(norm_pred, norm_target)
            char_cnt = len(norm_target)

            # 处理 target 为空的情况
            if char_cnt == 0:
                cer_value = 0.0 if errors == 0 else 1.0
            else:
                cer_value = errors / char_cnt

            self.total_errors += errors
            self.total_chars += char_cnt

            self.per_sample_results.append({
                "orig_pred": orig_pred,
                "orig_target": orig_target,
                "norm_pred": norm_pred,
                "norm_target": norm_target,
                "errors": errors,
                "target_chars": char_cnt,
                "cer": cer_value,
            })

    def compute(self) -> Dict[str, Any]:
        """计算整体 CER"""
        if self.total_chars == 0:
            overall_cer = 0.0 if self.total_errors == 0 else 1.0
        else:
            overall_cer = self.total_errors / self.total_chars

        return {
            "cer": overall_cer,
            "total_errors": self.total_errors,
            "total_chars": self.total_chars,
            "per_sample": self.per_sample_results,
        }


def print_result(result, title="结果"):
    """辅助打印函数"""
    print(f"\n=== {title} ===")
    print(f"整体 CER: {result['cer']:.4f}")
    print(f"总错误数: {result['total_errors']}")
    print(f"总参考字符数: {result['total_chars']}")
    print("单条样本:")
    for i, r in enumerate(result["per_sample"]):
        print(f"  样本{i}: CER={r['cer']:.4f}, errors={r['errors']}, "
              f"ref_len={r['target_chars']}")
        print(f"    orig_pred   : {r['orig_pred']}")
        print(f"    orig_target : {r['orig_target']}")
        print(f"    norm_pred   : {r['norm_pred']}")
        print(f"    norm_target : {r['norm_target']}")

def main():
    file_path = "pos.jsonl"

    print("=== 简单JSONL读取示例 ===")
    print(f"读取文件: {file_path}")
    print()
    print("=== 加载预训练模型 ===")
    # 自动从 ModelScope 下载预训练模型
    '''
    model = AutoModel(
        model="paraformer-zh",  # 正确的官方模型名（非实时，支持时间戳/热词）
        vad_model="fsmn-vad",  # VAD 简写名
        punc_model="ct-punc",  # 标点恢复简写名
        disable_update=True,  # 禁用更新检查，避免网络等待
        disable_pbar=True,  # 关闭进度条
        # spk_model="cam++",  # 说话人模型
    )


    '''
    model = AutoModel(
        model="./finetune_output",  # 正确的官方模型名（非实时，支持时间戳/热词）
        vad_model="fsmn-vad",  # VAD 简写名
        punc_model="ct-punc",  # 标点恢复简写名
        disable_update=True,  # 禁用更新检查，避免网络等待
        disable_pbar=True,  # 关闭进度条
        spk_model="cam++",  # 说话人模型
    )
    # checkpoint = torch.load("./finetune_output/model.pt.ep5", map_location="cpu")
    # model.model.load_state_dict(checkpoint, strict=False)

    # 读取前10行

    '''
    data=dict()
    content = simple_read_jsonl(file_path, limit=10)[0]
    label = content['识别文本']
    data['kws_path'] = content['唤醒音频']
    data['kws_txt'] = content['唤醒文本']
    data['cmd_path'] = content['识别音频']
    print(f'input:{data}')
    print(f'label:{label}')
    '''

    # 读取所有行
    contents = read_jsonl(file_path) # 读取所有行，返回列表
    '''
    label = contents['识别文本']
    data = dict()
    data['kws_path'] = contents['唤醒音频']
    data['kws_txt'] = contents['唤醒文本']
    data['cmd_path'] = contents['识别音频']
    print(f'input:{data}')
    print(f'input:{label}')
    res = model.generate(input=data['cmd_path'])  # , # use_vad=False)
    print(f'output:{res}')
    print(f'output:{remove_punctuation(res[0]["text"])}')
    # print(f'input:{data}')
    '''
    diff_count = 0
    total_count = 0
    with open('output_3.jsonl', 'w', encoding='utf-8') as f:
        for content in contents:
            label = content['识别文本']
            # label_2 = content['']
            data = dict()
            data['kws_path'] = content['唤醒音频']
            data['kws_txt'] = content['唤醒文本']
            data['cmd_path'] = content['识别音频']
            res = model.generate(input=data['cmd_path'])# , # use_vad=False)
            # res = model.generate(input=data['kws_path'])
            metric = CERMetric()
            metric.update(res[0]["text"], label)
            # metric.update(res[0]["text"], data['kws_txt'])
            res1 = metric.compute()
            print(f"整体 CER: {res1['cer']:.4f}")
            print(f"总错误数: {res1['total_errors']}")
            print(f"总参考字符数: {res1['total_chars']}")
            for i, r in enumerate(res1["per_sample"]):
                print(f"    norm_pred   : {r['norm_pred']}")
                print(f"    norm_target : {r['norm_target']}")
            diff_count += res1['total_errors']
            total_count += res1['total_chars']
            result = {
                "result": {
                    "results": [
                        {
                            "id": data['cmd_path'],
                            "content": r['norm_pred'],
                            "label": r['norm_target'],
                            "cer": f"{res1['cer']:.4f}"
                        }
                    ],
                }
            }
            f.write(json.dumps(result, ensure_ascii=False) + '\n')
            # print(f'input:{label}')

        result = {
            "final_cer": f"{(diff_count / total_count) * 100:.4f}%",
        }
        f.write(json.dumps(result, ensure_ascii=False) + '\n')
        print(f"最终不同百分比: {(diff_count / total_count) * 100:.2f}%")  # (diff_count / total) * 100
        '''
        if res:
            print(f'output:{remove_punctuation(res[0]["text"])}')
            diff, total, pct = char_diff_ratio(label, remove_punctuation(res[0]["text"]))
            print(f"不同字数: {diff}/{total}")
            print(f"不同百分比: {pct:.2f}%")
            diff_count += diff
            total_count += total
            result = {
                "result": {
                    "results": [
                        {
                            "id": data['cmd_path'],
                            "content": remove_punctuation(res[0]["text"]),
                            "label": label,
                            "cer": f"{pct:.2f}%"
                        }
                    ],
                }
            }
            f.write(json.dumps(result, ensure_ascii=False) + '\n')
        else:
            # 这里会打印出到底是哪个文件让 ASR 返回了空列表
            print(f"警告：以下文件识别结果为空 -> {data['cmd_path']}")
            # 可以选择跳过，或者写入一个空字符串
    result = {
        "final_cer": f"{(diff_count / total_count) * 100:.2f}%",
    }
    f.write(json.dumps(result, ensure_ascii=False) + '\n')
    
    
        '''

if __name__ == "__main__":
    main()